﻿using UnityEngine;
using System.Collections;

public class shipFire : MonoBehaviour {

	public GameObject bulletObj;

	private float lastBulletTime;

	// Use this for initialization
	void Start () {

		lastBulletTime = 0.0f;
	
	}
	
	// Update is called once per frame
	void Update () {

		lastBulletTime -= Time.deltaTime;

		if (Input.GetKeyDown (KeyCode.Space)) {
		
			if(lastBulletTime <= 0.0f)
			{
				Fire ();
				lastBulletTime = 0.5f;
			}

		}
	
	}

	void Fire()
	{
		Vector3 bulletPos = new Vector3 (transform.position.x, transform.position.y, 0);

		Instantiate (bulletObj, bulletPos, transform.rotation);

	}
}
