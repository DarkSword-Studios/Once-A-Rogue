﻿using UnityEngine;
using System.Collections;

public class shipMovement : MonoBehaviour {


	public Collider2D polyColi;

	public float rotationSpeed = 200.0f;

	private Vector3 speed = new Vector3(0.0f, 3.0f,0.0f);

	public gameManager gameMgr;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
		float rotation = Input.GetAxis("Horizontal") * rotationSpeed;

		rotation *= Time.deltaTime;

		transform.Rotate(0, 0 , -rotation);
		
		if( Input.GetAxis("Vertical") > 0 )
		{
			Vector2 vert = Input.GetAxis("Vertical") * speed;

			vert *= Time.deltaTime;

			GetComponent<Rigidbody2D>().AddRelativeForce(vert, ForceMode2D.Impulse);
		}


	}

	void OnTriggerEnter2D(Collider2D collision){
	

		if (collision.gameObject.tag != "Bullet") {
		
		
			transform.position = new Vector3(0,0,0);

			GetComponent<Rigidbody2D>().velocity = new Vector3(0,0,0);

		
		}

		gameMgr.shipHealth = gameMgr.shipHealth - 1;
	
	}
}
