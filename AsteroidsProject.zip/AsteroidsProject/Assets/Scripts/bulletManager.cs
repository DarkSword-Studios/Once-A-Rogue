﻿using UnityEngine;
using System.Collections;

public class bulletManager : MonoBehaviour {

	public Rigidbody2D rb;
	public float force;


	// Use this for initialization
	void Start () 
	{
		rb.AddForce (transform.up * force);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
