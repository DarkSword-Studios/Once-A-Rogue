﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class asteroidManager : MonoBehaviour {

	private gameManager gameMng;

	public List<GameObject> smallAsteroids;

	public GameObject smallAsteroid;
	// Use this for initialization
	void Start () {

		asteroidMovement ();
	
	}

	void asteroidMovement(){
	
		float asteroidSpeed = Random.Range (-10.0f, 100.0f);
		float asteroidAngVelo = Random.Range (0.0f, 100.0f);
		
		GameObject gameMngrObj = GameObject.FindWithTag ("GameManager");
		
		gameMng = gameMngrObj.GetComponent<gameManager> ();
		
		GetComponent<Rigidbody2D> ().AddForce (transform.up * asteroidSpeed);
		
		GetComponent<Rigidbody2D> ().angularVelocity = asteroidAngVelo;
	
	
	}

	void OnCollisionEnter2D(Collision2D collision){



		Vector3 smallAst1Pos = new Vector3 (transform.position.x + Random.Range(0,0.75f), transform.position.y, 0);
		
		Vector3 smallAst2Pos = new Vector3 (transform.position.x - Random.Range(0,0.75f), transform.position.y, 0);

		if (collision.gameObject.tag.Equals ("Bullet")) 
		{

			
			Destroy (collision.gameObject);
		

			if(tag.Equals("LargeAsteroid"))
			{

				GameObject smallAsteroid = smallAsteroids[Random.Range(0,smallAsteroids.Count)];
				GameObject smallAsteroid2 = smallAsteroids[Random.Range(0,smallAsteroids.Count)];

				Instantiate(smallAsteroid, smallAst1Pos, Quaternion.Euler(0,0,0));
				Instantiate(smallAsteroid2, smallAst2Pos, Quaternion.Euler(0,0,0));

				gameMng.score += 20;

			}

			if(tag.Equals("SmallAsteroid"))
			{
				gameMng.score +=20; 

			}
	
			Destroy (gameObject);

		}
	
	}
	

}
