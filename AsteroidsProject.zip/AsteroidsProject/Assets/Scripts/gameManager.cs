﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class gameManager : MonoBehaviour {

	public int shipHealth;
	public int score;

	//public GameObject asteroid;

	public List<GameObject> largeAsteroids;


	private int lastAsteroidSpawn;

	private float timeLeft;

	private GUIStyle guiStyle = new GUIStyle();
	private GUIStyle gameOverGui = new GUIStyle();

	// Use this for initialization
	void Start () {

		timeLeft = 2.5f;
		newGame ();



	
	}
	
	// Update is called once per frame
	void Update () {

		timeLeft -= Time.deltaTime;
		
		if (timeLeft < 0) 
		{
			asteroidSpawner ();
			timeLeft = 2.5f;
		}

		if (shipHealth <= 0) {
		
			gameOver();
		
		}
	
	}

	void asteroidSpawner (){

		float spawnPosX = Random.Range (-5.0f, 5.0f);
		float spawnPosY = Random.Range (-3.0f, 3.0f);

		float spawnAngle = Random.Range (0.0f, 360.0f);

		Vector3 spawnPos = new Vector3 (spawnPosX, spawnPosY, 0);

		GameObject asteroid = largeAsteroids [Random.Range (0, largeAsteroids.Count)];
		Instantiate(asteroid,spawnPos,Quaternion.Euler(0,0,spawnAngle));


	
	}

	void newGame (){
	
		shipHealth = 3;
		score = 0;

		for (int i = 0; i < 3; i++) 
		{
			float spawnPosX = Random.Range (-5.0f, 5.0f);
			float spawnPosY = Random.Range (0.0f, 3.0f);
			
			float spawnAngle = Random.Range (0.0f, 360.0f);
			
			Vector3 spawnPos = new Vector3 (spawnPosX, spawnPosY, 0);

			GameObject asteroid = largeAsteroids [Random.Range (0, largeAsteroids.Count)];

			Instantiate(asteroid,spawnPos,Quaternion.Euler(0,0,spawnAngle));
		}

	
	}

	void gameOver(){

		Time.timeScale = 0;

	
	}

	void OnGUI(){
	
		guiStyle.fontSize = 20;
		guiStyle.normal.textColor = Color.white;

		gameOverGui.fontSize = 60;
		gameOverGui.normal.textColor = Color.red;

		GUI.Label (new Rect (20,20,200,200), "Ship Health: " + shipHealth, guiStyle);
		GUI.Label (new Rect (20, 55, 200, 200), "Current Score: " + score, guiStyle);

		if (shipHealth <= 0) 
		{
		
			GUI.Box(new Rect(320,500,100,100),"Game Over", gameOverGui);
		}
	
	}

}


